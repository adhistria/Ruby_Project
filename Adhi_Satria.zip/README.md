# GoCLI

Project untuk menyelesaikan tugas second stage compfest

## gocli command

* gocli tanpa paramater
* gocli(file_name.csv) dengan parameter file csv
* gocli(10,20,30) dengan 3 parameter numerik
* -- quit to Exit

## Format Penyimpanan File dan Pengambilan File

History User disimpan pada format file .txt, dikarenakan mudahnya untuk menaruh data dan mengambil data pada file txt.
Sedangkan untuk pengambilan data menggunakan format file csv, karena format csv mudah dipisahkan sebagai array


## Built With
* [Ruby]

## Authors
* **Adhi Satria**
## Read File From CSV
File csv harus berformatkan sama seperti yang telah ada didalam folder


